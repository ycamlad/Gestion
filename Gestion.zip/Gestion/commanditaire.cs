﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion
{
  public  class Commanditaire : Personne
    {

        private string IDCommanditaire;

        public Commanditaire(string prenom, string surnom, string idCommanditaire) : base(prenom, surnom)
        {
            IDCommanditaire = idCommanditaire;
        }

        string IdCommanditaire
        {
            get => IDCommanditaire;
            set => IDCommanditaire = value;
        }

        public override string ToString()
        {
            return "ID Commanditaire: " + IDCommanditaire + "\r\tIdentifiant: " + base.ToString() ;
        }
    }
}
