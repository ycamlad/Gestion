﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion
{
    public class Don
    {
        private string IDDon;
        private string DateDuDon;
        private string IDDonateur;
        private string MntantDuDon;
        private string IDPrix;


        public Don(string idDon, string dateDuDon, string idDonateur, string mntantDuDon, string idPrix)
        {
            IDDon = idDon;
            DateDuDon = dateDuDon;
            IDDonateur = idDonateur;
            MntantDuDon = mntantDuDon;
            IDPrix = idPrix;
        }


        //public string IdDon
        //{
        //    get => IDDon;
        //    set => IDDon = value;
        //}

        //public string DateDuDon1
        //{
        //    get => DateDuDon;
        //    set => DateDuDon = value;
        //}

        //public string IdDonateur
        //{
        //    get => IDDonateur;
        //    set => IDDonateur = value;
        //}

      

        //public string IdPrix
        //{
        //    get => IDPrix;
        //    set => IDPrix = value;
        //}

        public override string ToString()
        {
            return base.ToString();
                //"ID Don: "+ IDDon+ "\tDate: " +DateDuDon+"\tID Donateur"+ IDDonateur+"\r\nID Prix: " + IDPrix +"\tMontant Du Don: "+ MntantDuDon;
        }
    }
}
