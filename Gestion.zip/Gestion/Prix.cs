﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion
{
   public class Prix
    {
        string IDPRIX;
        string Description;
        double Valeur;
        double DonMinimum;
        int Qnte_Originale;
        int Qnte_Disponible;
        string IDCommanditaire;

        public Prix(string idprix, string description, double valeur, double donMinimum, int qnteOriginale, int qnteDisponible, string idCommanditaire)
        {
            IDPRIX = idprix;
            Description = description;
            Valeur = valeur;
            DonMinimum = donMinimum;
            Qnte_Originale = qnteOriginale;
            Qnte_Disponible = qnteDisponible;
            IDCommanditaire = idCommanditaire;
        }

     

        public override string ToString()
        {
            return / "ID Prix: " + idprix + "\tDescription: " + description + "\tValeur: " + valeur + "\r\nDon Minimum: " + donMinimum + "\t Qantite Disponible: " + qnteDisponible+" ID Commanditaire: "+ idCommanditaire; 
        }
    }
}
