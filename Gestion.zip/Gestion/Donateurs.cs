﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion
{
    public class Donateur : Personne
    {
        private string IDDonateur;
        private string Adresse;
        private string Telephone;
        private string TypeDeCarte;
        private string NumeroDeCarte;
        private string DateExpiration;


        public Donateur(string prenom, string surnom, string idDonateur, string adresse, string telephone, string typeDeCarte, string numeroDeCarte, string dateExpiration) : base(prenom, surnom)
        {
            IDDonateur = idDonateur;
            Adresse = adresse;
            Telephone = telephone;
            TypeDeCarte = typeDeCarte;
            NumeroDeCarte = numeroDeCarte;
            DateExpiration = dateExpiration;
        }


        public string IdDonateur
        {
            get => IDDonateur;
            set => IDDonateur = value;
        }

        public string Adresse1
        {
            get => Adresse;
            set => Adresse = value;
        }

        public string Telephone1
        {
            get => Telephone;
            set => Telephone = value;
        }

        public string TypeDeCarte1
        {
            get => TypeDeCarte;
            set => TypeDeCarte = value;
        }

        public string NumeroDeCarte1
        {
            get => NumeroDeCarte;
            set => NumeroDeCarte = value;
        }

        public string DateExpiration1
        {
            get => DateExpiration;
            set => DateExpiration = value;
        }

        public override string ToString()
        {
            return " tel:" + Telephone + " Nom:"+base.ToString()  ;
        }
    }



}
