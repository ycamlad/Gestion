﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion
{
    public class Personne

    {
        string Prenom;
        string Surnom;

        public Personne(string prenom, string surnom)
        {
            Prenom = prenom;
            Surnom = surnom;
        }


        public override string ToString()
        {
            return  Prenom +" "+Surnom;
        }
    }

                
    




}
